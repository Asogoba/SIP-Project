package proxy;

import java.io.IOException;

import java.net.SocketException;
import java.util.ArrayList;
import java.util.Arrays;

import mensajesSIP.InviteMessage;
import mensajesSIP.NotFoundMessage;
import mensajesSIP.OKMessage;
import mensajesSIP.RegisterMessage;
import mensajesSIP.SDPMessage;
import mensajesSIP.SIPMessage;

public class ProxyTransactionLayer {
	private static final int IDLE = 0;
	private int state = IDLE;

	private ProxyUserLayer userLayer;
	private ProxyTransportLayer transportLayer;

	public ProxyTransactionLayer(int listenPort, ProxyUserLayer userLayer) throws SocketException {
		this.userLayer = userLayer;
		this.transportLayer = new ProxyTransportLayer(listenPort, this);
	}

	public void onMessageReceived(SIPMessage sipMessage) throws IOException {
		if (sipMessage instanceof InviteMessage) {
			InviteMessage inviteMessage = (InviteMessage) sipMessage;
			switch (state) {
			case IDLE:
				userLayer.onInviteReceived(inviteMessage);
				break;
			default:
				System.err.println("Unexpected message, throwing away");
				break;
			}
		} 
		else if (sipMessage instanceof RegisterMessage){
			RegisterMessage registerMessage = (RegisterMessage) sipMessage;
			
			
			for(User user: userLayer.getRegisteredUsers()) {
				if (user.getName()== registerMessage.getFromName() & user.getAddress()==registerMessage.getContact()){
					System.out.println("the user"+ "" +user.getName()+ ""+"is already registered");
					// send a 404 with the parameters received in the register message if the user is already registered
					NotFoundMessage message404 = new NotFoundMessage();
					message404.setFromName(registerMessage.getFromName());
					message404.setToName(registerMessage.getFromName());
					transportLayer.sendNotFoundMessage(message404,user.getAddress(), user.getPort());
				}
				else {
					userLayer.onRegisterReceived(registerMessage);
					System.out.println("the user"+ registerMessage.getFromName()+ "is now registered");
					// send 200OK with the parameters received in the register message if the user is now added to the registered users list
					OKMessage okMessage = new OKMessage();
					SDPMessage sdpMessage = new SDPMessage();
					sdpMessage.setOptions(new ArrayList<Integer>(Arrays.asList(96,97,98)));
					okMessage.setFromName(registerMessage.getFromName());
		            okMessage.setContact(registerMessage.getContact());
		            okMessage.setCallId(registerMessage.getCallId());
		            okMessage.setContentLength(0);
		            okMessage.setExpires("3600");
		            okMessage.setRecordRoute(registerMessage.getDestination());
		            okMessage.setRoute(registerMessage.getDestination());
		            okMessage.setToName(registerMessage.getToName());
		            okMessage.setSdp(new SDPMessage()); 
		            okMessage.setVias(registerMessage.getVias());
		            okMessage.setSdp(sdpMessage);
		            
					transportLayer.send(okMessage, user.getAddress(), user.getPort());
					}
			    }
		    }

				// check if the user is already registered
		
		else {
			System.err.println("Unexpected message, throwing away");
		}
}
	

	public void echoInvite(InviteMessage inviteMessage, String address, int port) throws IOException {
		transportLayer.send(inviteMessage, address, port);
	}
	
	public void echoregister(RegisterMessage registerMessage, String address, int port) throws IOException {
		transportLayer.send(registerMessage, address, port);
	}
	
	

	public void startListening() {
		transportLayer.startListening();
	}
	
	
}
