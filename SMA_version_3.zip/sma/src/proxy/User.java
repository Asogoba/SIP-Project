package proxy;

public class User {
	
	private int port;
	private String name;
	private String address;
	private int timeToExpire;
	
	
	public User (int port,String name, String address, int timeToExpire) {
		this.port = port;
		this.name = name;
		this.address = address;
		this.timeToExpire =  timeToExpire;
		
	}
	
	public int getPort() {
		return this.port;
		
	}
	public int getTime() {
		return this.timeToExpire;
		
	}
	
	public String getAddress() {
		return this.address;
		
	}
	
	public String getName() {
		return this.name;
		
	}
}
	
	
	
	

